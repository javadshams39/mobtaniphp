<?php
if( ! defined('sql102.b6b.ir') )
	define( 'sql102.b6b.ir', 'localhost' );
if( ! defined('b6bi_27935585') )
	define( 'b6bi_27935585');
if( ! defined('mohammad991400') )
	define( 'mohammad991400' );
if( ! defined('bitpaydb') )
	define( 'bitpaydb');
	
if( ! defined('CHARSET') )
	define( 'CHARSET', 'utf8mb4' );

$dbHost =	sql102.b6b.ir;
$dbUser =	b6bi_27935585;
$dbPass =	mohammad991400;
$dbname =	bitpaydb;

$charset =	CHARSET;